<?php
require("phpsqlinfo_dbinfo.php");

// Gets data from URL parameters
$type = $_GET['type'];
$gender = $_GET['gender'];
$baby = $_GET['baby'];
$disable = $_GET['disable'];
$lat = $_GET['lat'];
$lng = $_GET['lng'];
$description = $_GET['description'];

$type=$_POST['type'];
$t=$_POST['timestamp'];

if ($type=="getid"){
exec("zip -r ".$t."mydata2.kmz accessible.kml/");
echo $t;
}else{
$gender=$_POST['gender'];
$baby=$_POST['baby'];
$disable=$_POST['disable'];
$lat=$_POST['lat'];
$lng=$_POST['lng'];
$description =$_POST['description'];

// Opens a connection to a MySQL server
$connection=mysql_connect ($host, $username, $password);
if (!$connection) {
  die('Not connected : ' . mysql_error());
}

// Set the active MySQL database
$db_selected = mysql_select_db($database, $connection);
if (!$db_selected) {
  die ('Can\'t use db : ' . mysql_error());
}

// Insert new row with user data
$query = sprintf("INSERT INTO markers " .
         " (id, type, gender, baby, disable, lat, lng, description ) " .
         " VALUES (NULL, '%s', '%s', '%s', '%s', '%s', '%s', '%s');",
         mysql_real_escape_string($type),
         mysql_real_escape_string($gender),
     mysql_real_escape_string($baby),
     mysql_real_escape_string($disable),
         mysql_real_escape_string($lat),
         mysql_real_escape_string($lng),
         mysql_real_escape_string($description));

$result = mysql_query($query);

if (!$result) {
  die('Invalid query: ' . mysql_error());
}


$result1 = mysql_query("select * from markers");

chmod('/toiletfinder123/accessible.kml/',0777);//modified

$fp_write = fopen("./accessible.kml/doc.kml","w");//modified
fwrite($fp_write,"<?xml version=\"1.0\" encoding=\"UTF-8\"?><kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>outdoor.kml</name><Style id=\"icon-1733-E65100-normal\"><IconStyle><scale>1</scale><Icon><href>images/icon-1.png</href></Icon></IconStyle><LabelStyle><scale>0</scale></LabelStyle></Style><Style id=\"icon-1733-E65100-highlight\"><IconStyle><scale>1</scale><Icon><href>images/icon-1.png</href></Icon></IconStyle><LabelStyle><scale>1</scale></LabelStyle></Style><StyleMap id=\"icon-1733-E65100\"><Pair><key>normal</key><styleUrl>#icon-1733-E65100-normal</styleUrl></Pair><Pair><key>highlight</key><styleUrl>#icon-1733-E65100-highlight</styleUrl></Pair></StyleMap>");
while($row = mysql_fetch_array($result1,MYSQL_NUM))
{
    // fwrite($fp_write,$row[0]."\t".$row[1]."\t".$row[2]."\t".$row[3]."\t".$row[4]."\t".$row[5]."\t".$row[6]."\t".$row[7]."\n");
  fwrite($fp_write,"    <Placemark>
    <name>Out door toilet</name>
      <description>".$row[1].":".$row[2]." :".$row[3].":".$row[4].":".$row[7]."</description>
      <styleUrl>#icon-1733-E65100</styleUrl>
      <Point>
        <coordinates>".$row[6].",".$row[5].",0
        </coordinates>
      </Point>
    </Placemark>

");
} 
fwrite($fp_write,"  </Document>
</kml>");

fclose($fp_write);
exec("zip -r ".$t."mydata2.kmz accessible.kml/");
}


?>