<?php
require("phpsqlinfo_dbinfo.php");
$dom = new DOMDocument("1.0");
$node = $dom->createElement("markers");
$parnode = $dom->appendChild($node);
// Gets data from URL parameters
// Opens a connection to a MySQL server
$connection=mysql_connect ($host, $username, $password);
if (!$connection) {
  die('Not connected : ' . mysql_error());
}

// Set the active MySQL database
$db_selected = mysql_select_db($database, $connection);
if (!$db_selected) {
  die ('Can\'t use db : ' . mysql_error());
}




$result = mysql_query("select * from markers");


header("Content-type: text/xml");
while ($row = @mysql_fetch_assoc($result)){
  // Add to XML document node
  $node = $dom->createElement("marker");
  $newnode = $parnode->appendChild($node);
  $newnode->setAttribute("id",$row['id']);
  $newnode->setAttribute("type", $row['type']);
  $newnode->setAttribute("lat", $row['lat']);
  $newnode->setAttribute("lng", $row['lng']);
  $newnode->setAttribute("gender", $row['gender']);
  $newnode->setAttribute("baby", $row['baby']);
  $newnode->setAttribute("disable", $row['disable']);
  $newnode->setAttribute("description", $row['description']);
}

echo $dom->saveXML();

?>