<?php
$host="35.188.198.174";
$username="root";
$password="";
$database="toiletsinfo";


?>